<?php 
$root_url=$_SERVER['DOCUMENT_ROOT'].'/kiza/admin/';
$functions_url=$root_url.'includes/Function.inc.php';
$institution_url=$root_url.'core/Admin.core.php';
$system_url=$root_url.'core/System.core.php';
include_once $functions_url;
include_once $institution_url;
include_once $system_url;
?>