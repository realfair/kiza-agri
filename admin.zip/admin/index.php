<?php 
header("Location: dashboard");
?>