<?php 
require 'class_loader.php';
$systemPesticides=array();
$systemPesticides=$admin->loadSystemData("system_pesticide");
var_dump($systemPesticides);
?>