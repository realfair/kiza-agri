<div class="modal fade" id="exampleTabs" aria-hidden="true" aria-labelledby="exampleModalTabs"
 >
  <div class="modal-dialog modal-simple">
    <div class="modal-content">
      <div class="modal-header">
      	<h4 class="modal-title" id="exampleModalTabs">Add new Crop</h4> 
      </div>

      <div class="modal-body">
        <div class="row">
          <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="basic-form">
                        <form id="frm_save_crop">
                            <div class="form-group">
                                <label>Crop</label>
                                <input id="crop" type="text" class="form-control" placeholder="crop name" required="">
                            </div>
                            <button type="submit" class="btn btn-success">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <a href="crops_all" class="btn btn-default">Close</a>
      </div>
    </div>
  </div>
</div>  