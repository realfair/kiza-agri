<div class="left-sidebar">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav">
                <li class="nav-devider"></li>
                <li class="nav-label">Home</li>
                <li>
                    <a class="" href="dashboard" aria-expanded="false"><i class="fa fa-tachometer"></i>
                    <span class="hide-menu">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a class="" href="dashboard" aria-expanded="false"><i class="fa fa-users"></i>
                    <span class="hide-menu">Cooperatives</span>
                    </a>
                </li>
                <li>
                    <a class="" href="crops_all" aria-expanded="false"><i class="fa fa-gg-circle"></i>
                    <span class="hide-menu">Crops</span>
                    </a>
                </li>
                <li>
                    <a class="" href="fertilizers_all" aria-expanded="false"><i class="fa fa-sheqel"></i>
                    <span class="hide-menu">Fertilizers</span>
                    </a>
                </li>
                <li>
                    <a class="" href="pesticide_all" aria-expanded="false"><i class="fa fa-object-ungroup"></i>
                    <span class="hide-menu">Pesticides</span>
                    </a>
                </li>
                <li>
                    <a class="" href="users" aria-expanded="false"><i class="fa fa-users"></i>
                    <span class="hide-menu">Manage Users</span>
                    </a>
                </li>
                <li>
                    <a class="" href="#" aria-expanded="false"><i class="fa fa-gear"></i>
                    <span class="hide-menu">Settings</span>
                    </a>
                </li>
            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</div>