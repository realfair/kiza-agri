<script src="scripts/super/index.js"></script>
<script src="views/admin/modals/js/crop.js"></script>